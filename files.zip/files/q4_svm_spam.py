"""
Q4: Email Spam Detection using Support Vector Machine (SVM)
Dataset: spam.csv  (same as Q3)
Download: https://www.kaggle.com/datasets/uciml/sms-spam-collection-dataset
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import (confusion_matrix, accuracy_score,
                             precision_score, recall_score, ConfusionMatrixDisplay)
import warnings
warnings.filterwarnings('ignore')

# ─── 1. LOAD DATASET ───────────────────────────────────────────────────────────
try:
    df = pd.read_csv('spam.csv', encoding='latin-1')[['v1', 'v2']]
    df.columns = ['label', 'message']
    print("spam.csv loaded successfully.")
except FileNotFoundError:
    print("spam.csv not found. Creating sample dataset...")
    ham_msgs  = [
        "Hey, how are you doing today?",
        "Can we meet tomorrow for lunch?",
        "Call me when you get a chance.",
        "Happy birthday! Hope you have a great day.",
        "Don't forget the meeting at 3pm.",
        "I'll be there in 10 minutes.",
        "Thanks for helping me out yesterday.",
        "Are you free this weekend?",
        "Just checking in to see how things are going.",
        "Let me know if you need anything.",
    ] * 50
    spam_msgs = [
        "FREE entry in 2 a wkly competition to win FA Cup",
        "Congratulations! You've won a 1000 cash prize!",
        "URGENT: Your account has been hacked. Click here.",
        "Get a FREE iPhone now! Limited offer!",
        "You are selected for a lucky draw. Claim now!",
        "Win big cash prizes. Call 0800 now!",
        "Txt now to claim your prize worth 100.",
        "You have been awarded a 500 bonus!",
        "WINNER!! As a valued network customer click now.",
        "Call free for a chance to win!",
    ] * 20
    df = pd.DataFrame({
        'label':   ['ham']*len(ham_msgs) + ['spam']*len(spam_msgs),
        'message': ham_msgs + spam_msgs
    })

print(f"\nShape: {df.shape}")
print(df['label'].value_counts())

# ─── 2. PRE-PROCESSING ─────────────────────────────────────────────────────────
df['label_enc'] = (df['label'] == 'spam').astype(int)

vectorizer = TfidfVectorizer(max_features=3000, stop_words='english')
X = vectorizer.fit_transform(df['message']).toarray()
y = df['label_enc']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ─── 3. TRAIN SVM ──────────────────────────────────────────────────────────────
svm = SVC(kernel='linear', C=1.0, random_state=42)
svm.fit(X_train, y_train)
y_pred = svm.predict(X_test)

# ─── 4. EVALUATION ─────────────────────────────────────────────────────────────
cm        = confusion_matrix(y_test, y_pred)
accuracy  = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall    = recall_score(y_test, y_pred)

print(f"\n{'='*40}")
print(f"  Accuracy  : {accuracy:.4f}")
print(f"  Precision : {precision:.4f}")
print(f"  Recall    : {recall:.4f}")
print(f"{'='*40}")
print(f"\nConfusion Matrix:\n{cm}")

# Confusion Matrix Plot
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Ham', 'Spam'])
disp.plot(cmap='Oranges')
plt.title('SVM - Confusion Matrix (Spam Detection)')
plt.tight_layout()
plt.savefig('q4_confusion_matrix.png', dpi=100)
plt.show()

# Bar comparison of metrics
metrics = {'Accuracy': accuracy, 'Precision': precision, 'Recall': recall}
plt.figure(figsize=(6, 4))
plt.bar(metrics.keys(), metrics.values(), color=['steelblue', 'orange', 'green'])
plt.ylim(0, 1.1)
plt.title('SVM - Performance Metrics')
plt.ylabel('Score')
for i, (k, v) in enumerate(metrics.items()):
    plt.text(i, v + 0.02, f'{v:.3f}', ha='center')
plt.tight_layout()
plt.savefig('q4_metrics.png', dpi=100)
plt.show()
