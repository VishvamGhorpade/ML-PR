"""
Q1: Uber Fare Prediction using Linear Regression
Dataset: uber.csv
Download: https://www.kaggle.com/datasets/yasserh/uber-fares-dataset
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# ─── 1. LOAD DATASET ───────────────────────────────────────────────────────────
# If you don't have the file, this block creates a sample dataset
try:
    df = pd.read_csv('uber.csv')
    print("Dataset loaded successfully.")
except FileNotFoundError:
    print("uber.csv not found. Generating sample dataset...")
    np.random.seed(42)
    n = 1000
    df = pd.DataFrame({
        'fare_amount':     np.random.uniform(2.5, 100, n),
        'pickup_longitude':  np.random.uniform(-74.1, -73.7, n),
        'pickup_latitude':   np.random.uniform(40.5, 40.9, n),
        'dropoff_longitude': np.random.uniform(-74.1, -73.7, n),
        'dropoff_latitude':  np.random.uniform(40.5, 40.9, n),
        'passenger_count':   np.random.randint(1, 7, n),
    })

print(f"\nShape: {df.shape}")
print(df.head())

# ─── 2. PRE-PROCESSING ─────────────────────────────────────────────────────────
# Keep relevant columns
cols = ['fare_amount', 'pickup_longitude', 'pickup_latitude',
        'dropoff_longitude', 'dropoff_latitude', 'passenger_count']
df = df[[c for c in cols if c in df.columns]].dropna()

# Remove invalid fares and passenger counts
df = df[(df['fare_amount'] > 0) & (df['fare_amount'] < 500)]
df = df[(df['passenger_count'] > 0) & (df['passenger_count'] <= 6)]

# Compute trip distance using Haversine formula
def haversine(lat1, lon1, lat2, lon2):
    R = 6371  # Earth radius in km
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat/2)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon/2)**2
    return R * 2 * np.arcsin(np.sqrt(a))

df['distance_km'] = haversine(df['pickup_latitude'], df['pickup_longitude'],
                               df['dropoff_latitude'], df['dropoff_longitude'])

# Remove zero/very-short distances
df = df[df['distance_km'] > 0.1]
print(f"\nAfter preprocessing: {df.shape}")

# ─── 3. IDENTIFY OUTLIERS ──────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
axes[0].boxplot(df['fare_amount'])
axes[0].set_title('Fare Amount - Before Outlier Removal')
axes[0].set_ylabel('Fare ($)')

Q1 = df['fare_amount'].quantile(0.25)
Q3 = df['fare_amount'].quantile(0.75)
IQR = Q3 - Q1
df = df[(df['fare_amount'] >= Q1 - 1.5*IQR) & (df['fare_amount'] <= Q3 + 1.5*IQR)]

axes[1].boxplot(df['fare_amount'])
axes[1].set_title('Fare Amount - After Outlier Removal')
axes[1].set_ylabel('Fare ($)')
plt.tight_layout()
plt.savefig('q1_outliers.png', dpi=100)
plt.show()
print(f"\nAfter outlier removal: {df.shape}")

# ─── 4. CORRELATION ANALYSIS ───────────────────────────────────────────────────
feature_cols = ['fare_amount', 'distance_km', 'passenger_count']
corr_data = df[feature_cols]
plt.figure(figsize=(6, 4))
sns.heatmap(corr_data.corr(), annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Feature Correlation Heatmap')
plt.tight_layout()
plt.savefig('q1_correlation.png', dpi=100)
plt.show()
print("\nCorrelation with fare_amount:")
print(corr_data.corr()['fare_amount'].sort_values(ascending=False))

# ─── 5. TRAIN LINEAR REGRESSION ────────────────────────────────────────────────
X = df[['distance_km', 'passenger_count']]
y = df['fare_amount']

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)

# ─── 6. EVALUATION ─────────────────────────────────────────────────────────────
r2   = r2_score(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"\n{'='*40}")
print(f"  R² Score : {r2:.4f}")
print(f"  RMSE     : {rmse:.4f}")
print(f"{'='*40}")

# Prediction vs Actual plot
plt.figure(figsize=(7, 5))
plt.scatter(y_test, y_pred, alpha=0.5, color='steelblue')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
plt.xlabel('Actual Fare ($)')
plt.ylabel('Predicted Fare ($)')
plt.title('Linear Regression: Actual vs Predicted')
plt.tight_layout()
plt.savefig('q1_prediction.png', dpi=100)
plt.show()
