"""
Q10: Gradient Descent to find local minima of y = (x + 5)^2
Starting point: x = 2
"""

import numpy as np
import matplotlib.pyplot as plt

# ─── FUNCTION AND DERIVATIVE ───────────────────────────────────────────────────
def f(x):
    return (x + 5) ** 2

def df(x):
    return 2 * (x + 5)

# ─── GRADIENT DESCENT ALGORITHM ───────────────────────────────────────────────
def gradient_descent(start_x, learning_rate=0.1, max_iters=100, tolerance=1e-6):
    x = start_x
    history = [(x, f(x))]

    print(f"{'Iter':>5} {'x':>12} {'y':>12} {'Gradient':>12}")
    print("-" * 45)

    for i in range(max_iters):
        gradient = df(x)
        x_new = x - learning_rate * gradient
        history.append((x_new, f(x_new)))

        print(f"{i+1:5d} {x_new:12.6f} {f(x_new):12.6f} {gradient:12.6f}")

        if abs(x_new - x) < tolerance:
            print(f"\nConverged at iteration {i+1}")
            break
        x = x_new

    return x, f(x), history

# ─── RUN ──────────────────────────────────────────────────────────────────────
print("=" * 60)
print("  Gradient Descent: Finding Minima of y = (x + 5)^2")
print("  Starting x = 2,  Learning Rate = 0.1")
print("=" * 60)

start_x       = 2
learning_rate = 0.1

x_min, y_min, history = gradient_descent(start_x, learning_rate)

print(f"\n{'='*60}")
print(f"  Minimum found at: x = {x_min:.6f}")
print(f"  Minimum value  : y = {y_min:.6f}")
print(f"  True minimum   : x = -5, y = 0")
print(f"{'='*60}")

# ─── VISUALIZATION ────────────────────────────────────────────────────────────
x_vals = np.linspace(-8, 4, 300)
y_vals = f(x_vals)

history_x = [h[0] for h in history]
history_y = [h[1] for h in history]

fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Left: Descent path on function curve
axes[0].plot(x_vals, y_vals, 'b-', linewidth=2, label='y = (x+5)²')
axes[0].scatter(history_x, history_y, color='red', s=30, zorder=5, label='Steps')
axes[0].plot(history_x, history_y, 'r--', alpha=0.4)
axes[0].scatter([start_x], [f(start_x)], color='green', s=150, zorder=6,
                label=f'Start (x={start_x})')
axes[0].scatter([x_min], [y_min], color='orange', s=200, marker='*', zorder=6,
                label=f'Min (x≈{x_min:.2f})')
axes[0].set_xlabel('x'); axes[0].set_ylabel('y')
axes[0].set_title('Gradient Descent Path on y=(x+5)²')
axes[0].legend(); axes[0].grid(True)

# Right: x convergence over iterations
axes[1].plot(history_x, 'o-', markersize=4, color='steelblue', label='x values')
axes[1].axhline(y=-5, color='red', linestyle='--', label='True min x=-5')
axes[1].set_xlabel('Iteration'); axes[1].set_ylabel('x')
axes[1].set_title('Convergence of x over Iterations')
axes[1].legend(); axes[1].grid(True)

plt.tight_layout()
plt.savefig('q10_gradient_descent.png', dpi=100)
plt.show()
