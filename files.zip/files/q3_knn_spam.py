"""
Q3: Email Spam Detection using K-Nearest Neighbors (KNN)
Dataset: spam.csv
Download: https://www.kaggle.com/datasets/uciml/sms-spam-collection-dataset
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, ConfusionMatrixDisplay
import warnings
warnings.filterwarnings('ignore')

# ─── 1. LOAD DATASET ───────────────────────────────────────────────────────────
try:
    df = pd.read_csv('spam.csv', encoding='latin-1')[['v1', 'v2']]
    df.columns = ['label', 'message']
    print("spam.csv loaded successfully.")
except FileNotFoundError:
    print("spam.csv not found. Creating sample dataset...")
    ham_msgs  = [
        "Hey, how are you doing today?",
        "Can we meet tomorrow for lunch?",
        "Call me when you get a chance.",
        "Happy birthday! Hope you have a great day.",
        "Don't forget the meeting at 3pm.",
        "I'll be there in 10 minutes.",
        "Thanks for helping me out yesterday.",
        "Are you free this weekend?",
        "Just checking in to see how things are going.",
        "Let me know if you need anything.",
    ] * 50
    spam_msgs = [
        "FREE entry in 2 a wkly competition to win FA Cup",
        "Congratulations! You've won a 1000 cash prize!",
        "URGENT: Your account has been hacked. Click here.",
        "Get a FREE iPhone now! Limited offer!",
        "You are selected for a lucky draw. Claim now!",
        "Win big cash prizes. Call 0800 now!",
        "Txt now to claim your prize worth 100.",
        "You have been awarded a 500 bonus!",
        "WINNER!! As a valued network customer click now.",
        "Call free for a chance to win!",
    ] * 20
    df = pd.DataFrame({
        'label':   ['ham']*len(ham_msgs) + ['spam']*len(spam_msgs),
        'message': ham_msgs + spam_msgs
    })

print(f"\nShape: {df.shape}")
print(df['label'].value_counts())

# ─── 2. PRE-PROCESSING ─────────────────────────────────────────────────────────
df['label_enc'] = (df['label'] == 'spam').astype(int)  # ham=0, spam=1

# TF-IDF Vectorization
vectorizer = TfidfVectorizer(max_features=3000, stop_words='english')
X = vectorizer.fit_transform(df['message']).toarray()
y = df['label_enc']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ─── 3. FIND BEST K ────────────────────────────────────────────────────────────
k_values = range(1, 21)
accuracies = []
for k in k_values:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    accuracies.append(accuracy_score(y_test, knn.predict(X_test)))

best_k = k_values[np.argmax(accuracies)]
print(f"\nBest K = {best_k} with Accuracy = {max(accuracies):.4f}")

plt.figure(figsize=(8, 4))
plt.plot(k_values, accuracies, marker='o', color='steelblue')
plt.xlabel('K Value')
plt.ylabel('Accuracy')
plt.title('KNN: Accuracy vs K')
plt.axvline(x=best_k, color='red', linestyle='--', label=f'Best K={best_k}')
plt.legend()
plt.tight_layout()
plt.savefig('q3_k_selection.png', dpi=100)
plt.show()

# ─── 4. TRAIN KNN ──────────────────────────────────────────────────────────────
knn = KNeighborsClassifier(n_neighbors=best_k)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)

# ─── 5. EVALUATION ─────────────────────────────────────────────────────────────
cm        = confusion_matrix(y_test, y_pred)
accuracy  = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall    = recall_score(y_test, y_pred)

print(f"\n{'='*40}")
print(f"  Accuracy  : {accuracy:.4f}")
print(f"  Precision : {precision:.4f}")
print(f"  Recall    : {recall:.4f}")
print(f"{'='*40}")
print(f"\nConfusion Matrix:\n{cm}")

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Ham', 'Spam'])
disp.plot(cmap='Blues')
plt.title('KNN - Confusion Matrix (Spam Detection)')
plt.tight_layout()
plt.savefig('q3_confusion_matrix.png', dpi=100)
plt.show()
