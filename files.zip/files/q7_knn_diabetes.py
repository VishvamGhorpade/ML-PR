"""
Q7: KNN on Diabetes Dataset
Dataset: diabetes.csv (Pima Indians Diabetes Dataset)
Download: https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (confusion_matrix, accuracy_score,
                             precision_score, recall_score, ConfusionMatrixDisplay)
import warnings
warnings.filterwarnings('ignore')

# ─── 1. LOAD DATASET ───────────────────────────────────────────────────────────
try:
    df = pd.read_csv('diabetes.csv')
    print("diabetes.csv loaded successfully.")
except FileNotFoundError:
    print("diabetes.csv not found. Generating sample dataset...")
    np.random.seed(42)
    n = 768
    df = pd.DataFrame({
        'Pregnancies':              np.random.randint(0, 17, n),
        'Glucose':                  np.random.randint(44, 199, n),
        'BloodPressure':            np.random.randint(24, 122, n),
        'SkinThickness':            np.random.randint(0, 99, n),
        'Insulin':                  np.random.randint(0, 846, n),
        'BMI':                      np.round(np.random.uniform(0, 67, n), 1),
        'DiabetesPedigreeFunction': np.round(np.random.uniform(0.07, 2.4, n), 3),
        'Age':                      np.random.randint(21, 81, n),
        'Outcome':                  np.random.choice([0, 1], n, p=[0.65, 0.35]),
    })

print(f"\nShape: {df.shape}")
print(df.head())

# ─── 2. PRE-PROCESSING ─────────────────────────────────────────────────────────
# Replace 0s with NaN in medical columns (biologically invalid)
zero_cols = ['Glucose', 'BloodPressure', 'SkinThickness', 'Insulin', 'BMI']
df[zero_cols] = df[zero_cols].replace(0, np.nan)
df.fillna(df.median(), inplace=True)

X = df.drop('Outcome', axis=1)
y = df['Outcome']

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2,
                                                     random_state=42, stratify=y)

# ─── 3. FIND BEST K ────────────────────────────────────────────────────────────
k_values = range(1, 21)
accuracies = []
for k in k_values:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    accuracies.append(accuracy_score(y_test, knn.predict(X_test)))

best_k = k_values[np.argmax(accuracies)]
print(f"\nBest K = {best_k}, Accuracy = {max(accuracies):.4f}")

plt.figure(figsize=(8, 4))
plt.plot(list(k_values), accuracies, marker='o', color='darkorange')
plt.axvline(x=best_k, color='red', linestyle='--', label=f'Best K={best_k}')
plt.xlabel('K'); plt.ylabel('Accuracy')
plt.title('KNN: Accuracy vs K (Diabetes)')
plt.legend(); plt.grid(True)
plt.tight_layout()
plt.savefig('q7_k_selection.png', dpi=100)
plt.show()

# ─── 4. TRAIN & PREDICT ────────────────────────────────────────────────────────
knn = KNeighborsClassifier(n_neighbors=best_k)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)

# ─── 5. EVALUATION ─────────────────────────────────────────────────────────────
cm         = confusion_matrix(y_test, y_pred)
accuracy   = accuracy_score(y_test, y_pred)
error_rate = 1 - accuracy
precision  = precision_score(y_test, y_pred)
recall     = recall_score(y_test, y_pred)

print(f"\n{'='*40}")
print(f"  Accuracy   : {accuracy:.4f}")
print(f"  Error Rate : {error_rate:.4f}")
print(f"  Precision  : {precision:.4f}")
print(f"  Recall     : {recall:.4f}")
print(f"{'='*40}")
print(f"\nConfusion Matrix:\n{cm}")

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['No Diabetes', 'Diabetes'])
disp.plot(cmap='Greens')
plt.title('KNN - Confusion Matrix (Diabetes)')
plt.tight_layout()
plt.savefig('q7_confusion_matrix.png', dpi=100)
plt.show()
