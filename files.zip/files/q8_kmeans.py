"""
Q8: K-Means Clustering on Sales Data
Dataset: sample.csv (Sales data)
If you don't have sample.csv, a synthetic one is auto-generated.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# ─── 1. LOAD DATASET ───────────────────────────────────────────────────────────
try:
    df = pd.read_csv('sample.csv')
    print("sample.csv loaded successfully.")
    print(df.head())
except FileNotFoundError:
    print("sample.csv not found. Generating sample sales dataset...")
    np.random.seed(42)
    n = 200
    df = pd.DataFrame({
        'CustomerID':   np.arange(1, n + 1),
        'AnnualIncome': np.random.randint(15000, 150000, n),
        'SpendingScore': np.random.randint(1, 100, n),
        'Age':           np.random.randint(18, 70, n),
    })
    df.to_csv('sample.csv', index=False)
    print("Generated sample.csv with", n, "records.")

print(f"\nShape: {df.shape}")
print(df.describe())

# ─── 2. SELECT FEATURES ────────────────────────────────────────────────────────
# Use numerical columns for clustering (exclude IDs)
num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
id_cols  = [c for c in num_cols if 'id' in c.lower() or 'ID' in c]
feature_cols = [c for c in num_cols if c not in id_cols][:3]  # use up to 3 features
print(f"\nFeatures used for clustering: {feature_cols}")

X = df[feature_cols].dropna()
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ─── 3. ELBOW METHOD ───────────────────────────────────────────────────────────
inertias = []
K_range = range(1, 11)
for k in K_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(X_scaled)
    inertias.append(km.inertia_)

plt.figure(figsize=(8, 4))
plt.plot(list(K_range), inertias, marker='o', color='steelblue', linewidth=2)
plt.xlabel('Number of Clusters (K)')
plt.ylabel('Inertia (WCSS)')
plt.title('Elbow Method - Optimal K')
plt.grid(True)
plt.tight_layout()
plt.savefig('q8_elbow.png', dpi=100)
plt.show()

# ─── 4. DETERMINE OPTIMAL K (simple elbow detection) ──────────────────────────
diffs = np.diff(inertias)
optimal_k = int(np.argmin(np.diff(diffs)) + 2)
print(f"\nOptimal K from elbow method: {optimal_k}")

# ─── 5. TRAIN K-MEANS ──────────────────────────────────────────────────────────
km = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
df_cluster = X.copy()
df_cluster['Cluster'] = km.fit_predict(X_scaled)

print(f"\nCluster distribution:\n{df_cluster['Cluster'].value_counts().sort_index()}")

# ─── 6. VISUALIZE CLUSTERS ─────────────────────────────────────────────────────
colors = plt.cm.tab10(np.linspace(0, 1, optimal_k))

plt.figure(figsize=(8, 5))
for c in range(optimal_k):
    subset = df_cluster[df_cluster['Cluster'] == c]
    plt.scatter(subset[feature_cols[0]], subset[feature_cols[1]],
                label=f'Cluster {c}', s=50, alpha=0.7)

centers = scaler.inverse_transform(km.cluster_centers_)
plt.scatter(centers[:, 0], centers[:, 1],
            marker='X', s=200, c='black', label='Centroids', zorder=10)
plt.xlabel(feature_cols[0])
plt.ylabel(feature_cols[1])
plt.title(f'K-Means Clustering (K={optimal_k})')
plt.legend()
plt.tight_layout()
plt.savefig('q8_clusters.png', dpi=100)
plt.show()

print("\nCluster Means:")
print(df_cluster.groupby('Cluster').mean().round(2))
