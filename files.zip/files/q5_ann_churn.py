"""
Q5: Bank Customer Churn Prediction using ANN
Dataset: Churn_Modelling.csv
Download: https://www.kaggle.com/datasets/shrutimechlearn/churn-modelling
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (confusion_matrix, accuracy_score,
                             precision_score, recall_score, ConfusionMatrixDisplay)
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
import warnings
warnings.filterwarnings('ignore')

# ─── 1. LOAD DATASET ───────────────────────────────────────────────────────────
try:
    df = pd.read_csv('Churn_Modelling.csv')
    print("Dataset loaded successfully.")
    print(df.head())
except FileNotFoundError:
    print("Churn_Modelling.csv not found. Generating sample dataset...")
    np.random.seed(42)
    n = 1000
    df = pd.DataFrame({
        'CreditScore':    np.random.randint(300, 850, n),
        'Geography':      np.random.choice(['France', 'Germany', 'Spain'], n),
        'Gender':         np.random.choice(['Male', 'Female'], n),
        'Age':            np.random.randint(18, 70, n),
        'Tenure':         np.random.randint(0, 10, n),
        'Balance':        np.random.uniform(0, 250000, n),
        'NumOfProducts':  np.random.randint(1, 5, n),
        'HasCrCard':      np.random.randint(0, 2, n),
        'IsActiveMember': np.random.randint(0, 2, n),
        'EstimatedSalary':np.random.uniform(10000, 200000, n),
        'Exited':         np.random.choice([0, 1], n, p=[0.8, 0.2]),
    })

# ─── 2. PRE-PROCESSING ─────────────────────────────────────────────────────────
# Drop unnecessary columns if they exist
df.drop(columns=[c for c in ['RowNumber', 'CustomerId', 'Surname'] if c in df.columns],
        inplace=True)

# Encode categorical variables
le = LabelEncoder()
df['Gender'] = le.fit_transform(df['Gender'])

# One-hot encode Geography
df = pd.get_dummies(df, columns=['Geography'], drop_first=True)

X = df.drop('Exited', axis=1)
y = df['Exited']

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2,
                                                     random_state=42, stratify=y)

print(f"\nTraining samples: {X_train.shape[0]}, Test samples: {X_test.shape[0]}")
print(f"Features: {X.shape[1]}")

# ─── 3. BUILD ANN ──────────────────────────────────────────────────────────────
model = Sequential([
    Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    Dropout(0.3),
    Dense(32, activation='relu'),
    Dropout(0.2),
    Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
model.summary()

# ─── 4. TRAIN ANN ──────────────────────────────────────────────────────────────
history = model.fit(X_train, y_train, epochs=30, batch_size=32,
                    validation_split=0.1, verbose=1)

# Training history plot
plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Acc')
plt.plot(history.history['val_accuracy'], label='Val Acc')
plt.title('Model Accuracy')
plt.xlabel('Epoch'); plt.ylabel('Accuracy')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Val Loss')
plt.title('Model Loss')
plt.xlabel('Epoch'); plt.ylabel('Loss')
plt.legend()
plt.tight_layout()
plt.savefig('q5_training_history.png', dpi=100)
plt.show()

# ─── 5. EVALUATION ─────────────────────────────────────────────────────────────
y_prob = model.predict(X_test)
y_pred = (y_prob > 0.5).astype(int).flatten()

cm        = confusion_matrix(y_test, y_pred)
accuracy  = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall    = recall_score(y_test, y_pred)

print(f"\n{'='*40}")
print(f"  Accuracy  : {accuracy:.4f}")
print(f"  Precision : {precision:.4f}")
print(f"  Recall    : {recall:.4f}")
print(f"{'='*40}")

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Stayed', 'Churned'])
disp.plot(cmap='Purples')
plt.title('ANN - Confusion Matrix (Customer Churn)')
plt.tight_layout()
plt.savefig('q5_confusion_matrix.png', dpi=100)
plt.show()
