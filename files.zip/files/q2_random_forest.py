"""
Q2: Uber Fare Prediction using Random Forest Regression
Dataset: uber.csv  (same as Q1)
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import warnings
warnings.filterwarnings('ignore')

# ─── 1. LOAD DATASET ───────────────────────────────────────────────────────────
try:
    df = pd.read_csv('uber.csv')
    print("Dataset loaded successfully.")
except FileNotFoundError:
    print("uber.csv not found. Generating sample dataset...")
    np.random.seed(42)
    n = 1000
    df = pd.DataFrame({
        'fare_amount':       np.random.uniform(2.5, 100, n),
        'pickup_longitude':  np.random.uniform(-74.1, -73.7, n),
        'pickup_latitude':   np.random.uniform(40.5, 40.9, n),
        'dropoff_longitude': np.random.uniform(-74.1, -73.7, n),
        'dropoff_latitude':  np.random.uniform(40.5, 40.9, n),
        'passenger_count':   np.random.randint(1, 7, n),
    })

# ─── 2. PRE-PROCESSING ─────────────────────────────────────────────────────────
cols = ['fare_amount', 'pickup_longitude', 'pickup_latitude',
        'dropoff_longitude', 'dropoff_latitude', 'passenger_count']
df = df[[c for c in cols if c in df.columns]].dropna()
df = df[(df['fare_amount'] > 0) & (df['fare_amount'] < 500)]
df = df[(df['passenger_count'] > 0) & (df['passenger_count'] <= 6)]

def haversine(lat1, lon1, lat2, lon2):
    R = 6371
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1; dlon = lon2 - lon1
    a = np.sin(dlat/2)**2 + np.cos(lat1)*np.cos(lat2)*np.sin(dlon/2)**2
    return R * 2 * np.arcsin(np.sqrt(a))

df['distance_km'] = haversine(df['pickup_latitude'], df['pickup_longitude'],
                               df['dropoff_latitude'], df['dropoff_longitude'])
df = df[df['distance_km'] > 0.1]
print(f"After preprocessing: {df.shape}")

# ─── 3. IDENTIFY OUTLIERS ──────────────────────────────────────────────────────
Q1 = df['fare_amount'].quantile(0.25)
Q3 = df['fare_amount'].quantile(0.75)
IQR = Q3 - Q1
df = df[(df['fare_amount'] >= Q1 - 1.5*IQR) & (df['fare_amount'] <= Q3 + 1.5*IQR)]

plt.figure(figsize=(6, 4))
plt.boxplot(df['fare_amount'])
plt.title('Fare Amount Boxplot (after outlier removal)')
plt.ylabel('Fare ($)')
plt.tight_layout()
plt.savefig('q2_outliers.png', dpi=100)
plt.show()
print(f"After outlier removal: {df.shape}")

# ─── 4. CORRELATION ANALYSIS ───────────────────────────────────────────────────
plt.figure(figsize=(6, 4))
sns.heatmap(df[['fare_amount', 'distance_km', 'passenger_count']].corr(),
            annot=True, cmap='Blues', fmt='.2f')
plt.title('Correlation Heatmap')
plt.tight_layout()
plt.savefig('q2_correlation.png', dpi=100)
plt.show()

# ─── 5. TRAIN RANDOM FOREST ────────────────────────────────────────────────────
X = df[['distance_km', 'passenger_count']]
y = df['fare_amount']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)
y_pred = rf_model.predict(X_test)

# ─── 6. EVALUATION ─────────────────────────────────────────────────────────────
r2   = r2_score(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"\n{'='*40}")
print(f"  R² Score : {r2:.4f}")
print(f"  RMSE     : {rmse:.4f}")
print(f"{'='*40}")

# Feature importance
plt.figure(figsize=(6, 4))
feat_imp = pd.Series(rf_model.feature_importances_, index=X.columns)
feat_imp.plot(kind='barh', color='steelblue')
plt.title('Feature Importance - Random Forest')
plt.tight_layout()
plt.savefig('q2_feature_importance.png', dpi=100)
plt.show()

# Actual vs Predicted
plt.figure(figsize=(7, 5))
plt.scatter(y_test, y_pred, alpha=0.5, color='green')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
plt.xlabel('Actual Fare ($)')
plt.ylabel('Predicted Fare ($)')
plt.title('Random Forest: Actual vs Predicted')
plt.tight_layout()
plt.savefig('q2_prediction.png', dpi=100)
plt.show()
