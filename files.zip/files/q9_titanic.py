"""
Q9: Titanic Survival Prediction using Random Forest Classifier
Dataset: titanic.csv / train.csv
Download: https://www.kaggle.com/c/titanic/data
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (confusion_matrix, accuracy_score,
                             precision_score, recall_score,
                             classification_report, ConfusionMatrixDisplay)
import warnings
warnings.filterwarnings('ignore')

# ─── 1. LOAD DATASET ───────────────────────────────────────────────────────────
try:
    # Try common filenames
    for fname in ['train.csv', 'titanic.csv']:
        try:
            df = pd.read_csv(fname)
            print(f"Loaded {fname} successfully.")
            break
        except FileNotFoundError:
            continue
    else:
        raise FileNotFoundError
except FileNotFoundError:
    print("Titanic dataset not found. Generating sample dataset...")
    np.random.seed(42)
    n = 891
    df = pd.DataFrame({
        'PassengerId': np.arange(1, n+1),
        'Survived':    np.random.choice([0, 1], n, p=[0.62, 0.38]),
        'Pclass':      np.random.choice([1, 2, 3], n, p=[0.24, 0.21, 0.55]),
        'Name':        [f'Passenger {i}' for i in range(n)],
        'Sex':         np.random.choice(['male', 'female'], n, p=[0.65, 0.35]),
        'Age':         np.where(np.random.rand(n) < 0.2, np.nan,
                                np.random.randint(1, 80, n).astype(float)),
        'SibSp':       np.random.randint(0, 5, n),
        'Parch':       np.random.randint(0, 4, n),
        'Fare':        np.round(np.random.uniform(5, 500, n), 2),
        'Embarked':    np.random.choice(['S', 'C', 'Q', None], n, p=[0.7, 0.2, 0.08, 0.02]),
    })

print(f"\nShape: {df.shape}")
print(df.head())
print(f"\nMissing values:\n{df.isnull().sum()[df.isnull().sum() > 0]}")

# ─── 2. PRE-PROCESSING ─────────────────────────────────────────────────────────
# Drop columns not useful for prediction
df.drop(columns=[c for c in ['PassengerId', 'Name', 'Ticket', 'Cabin'] if c in df.columns],
        inplace=True)

# Fill missing values
df['Age'].fillna(df['Age'].median(), inplace=True)
df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)
df['Fare'].fillna(df['Fare'].median(), inplace=True)

# Encode categorical
df['Sex'] = (df['Sex'] == 'female').astype(int)
df = pd.get_dummies(df, columns=['Embarked'], drop_first=True)

# Feature engineering
df['FamilySize'] = df['SibSp'] + df['Parch'] + 1

print(f"\nFinal columns: {list(df.columns)}")
print(f"Survival rate: {df['Survived'].mean():.2%}")

# ─── 3. VISUALIZE SURVIVAL BY KEY FEATURES ─────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(14, 4))

# By Sex
sex_surv = df.groupby('Sex')['Survived'].mean()
axes[0].bar(['Male', 'Female'], sex_surv.values, color=['steelblue', 'coral'])
axes[0].set_title('Survival Rate by Sex')
axes[0].set_ylabel('Survival Rate')

# By Pclass
pclass_surv = df.groupby('Pclass')['Survived'].mean()
axes[1].bar(pclass_surv.index, pclass_surv.values, color=['gold', 'silver', 'brown'])
axes[1].set_title('Survival Rate by Class')
axes[1].set_xlabel('Passenger Class')

# Age distribution
axes[2].hist(df[df['Survived']==1]['Age'], alpha=0.6, label='Survived', color='green', bins=20)
axes[2].hist(df[df['Survived']==0]['Age'], alpha=0.6, label='Not Survived', color='red', bins=20)
axes[2].set_title('Age Distribution by Survival')
axes[2].set_xlabel('Age'); axes[2].legend()

plt.tight_layout()
plt.savefig('q9_eda.png', dpi=100)
plt.show()

# ─── 4. TRAIN MODEL ────────────────────────────────────────────────────────────
X = df.drop('Survived', axis=1)
y = df['Survived']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,
                                                     random_state=42, stratify=y)

clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)

# ─── 5. EVALUATION ─────────────────────────────────────────────────────────────
cm        = confusion_matrix(y_test, y_pred)
accuracy  = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall    = recall_score(y_test, y_pred)

print(f"\n{'='*40}")
print(f"  Accuracy  : {accuracy:.4f}")
print(f"  Precision : {precision:.4f}")
print(f"  Recall    : {recall:.4f}")
print(f"{'='*40}")
print("\nClassification Report:")
print(classification_report(y_test, y_pred, target_names=['Not Survived', 'Survived']))

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Not Survived', 'Survived'])
disp.plot(cmap='Blues')
plt.title('Random Forest - Confusion Matrix (Titanic)')
plt.tight_layout()
plt.savefig('q9_confusion_matrix.png', dpi=100)
plt.show()

# Feature Importance
feat_imp = pd.Series(clf.feature_importances_, index=X.columns).sort_values(ascending=True)
plt.figure(figsize=(7, 5))
feat_imp.plot(kind='barh', color='steelblue')
plt.title('Feature Importance - Titanic Classifier')
plt.tight_layout()
plt.savefig('q9_feature_importance.png', dpi=100)
plt.show()
