"""
Q6: Gradient Descent to find local minima of y = (x + 3)^2
Starting point: x = 2
"""

import numpy as np
import matplotlib.pyplot as plt

# ─── FUNCTION AND DERIVATIVE ───────────────────────────────────────────────────
def f(x):
    return (x + 3) ** 2

def df(x):
    return 2 * (x + 3)

# ─── GRADIENT DESCENT ALGORITHM ───────────────────────────────────────────────
def gradient_descent(start_x, learning_rate=0.1, max_iters=100, tolerance=1e-6):
    x = start_x
    history = [(x, f(x))]

    for i in range(max_iters):
        gradient = df(x)
        x_new = x - learning_rate * gradient

        history.append((x_new, f(x_new)))

        print(f"Iter {i+1:3d}: x = {x_new:10.6f}, y = {f(x_new):10.6f}, gradient = {gradient:10.6f}")

        if abs(x_new - x) < tolerance:
            print(f"\nConverged at iteration {i+1}")
            break
        x = x_new

    return x, f(x), history

# ─── RUN GRADIENT DESCENT ─────────────────────────────────────────────────────
print("=" * 60)
print("  Gradient Descent: Finding Minima of y = (x + 3)^2")
print("  Starting x = 2,  Learning Rate = 0.1")
print("=" * 60)

start_x       = 2
learning_rate = 0.1

x_min, y_min, history = gradient_descent(start_x, learning_rate)

print(f"\n{'='*60}")
print(f"  Minimum found at: x = {x_min:.6f}")
print(f"  Minimum value  : y = {y_min:.6f}")
print(f"  True minimum   : x = -3, y = 0")
print(f"{'='*60}")

# ─── VISUALIZATION ────────────────────────────────────────────────────────────
x_vals = np.linspace(-6, 4, 300)
y_vals = f(x_vals)

history_x = [h[0] for h in history]
history_y = [h[1] for h in history]

plt.figure(figsize=(10, 5))

# Left: Function curve with descent path
plt.subplot(1, 2, 1)
plt.plot(x_vals, y_vals, 'b-', linewidth=2, label='y = (x+3)²')
plt.scatter(history_x, history_y, color='red', s=30, zorder=5, label='Descent steps')
plt.plot(history_x, history_y, 'r--', alpha=0.5)
plt.scatter([history_x[0]], [history_y[0]], color='green', s=100, zorder=6, label=f'Start (x={start_x})')
plt.scatter([x_min], [y_min], color='orange', s=100, zorder=6, marker='*', label=f'Minimum (x≈{x_min:.2f})')
plt.xlabel('x'); plt.ylabel('y')
plt.title('Gradient Descent Path')
plt.legend(); plt.grid(True)

# Right: Convergence of x over iterations
plt.subplot(1, 2, 2)
plt.plot(history_x, marker='o', markersize=3, color='steelblue')
plt.axhline(y=-3, color='red', linestyle='--', label='True minimum x=-3')
plt.xlabel('Iteration'); plt.ylabel('x value')
plt.title('Convergence of x')
plt.legend(); plt.grid(True)

plt.tight_layout()
plt.savefig('q6_gradient_descent.png', dpi=100)
plt.show()
